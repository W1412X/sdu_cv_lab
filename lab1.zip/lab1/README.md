## Usage  
- ensure opencv4.x.x is installed  
- add run permission to the run.sh  
- run the run.sh under the catalog `lab1`  
  